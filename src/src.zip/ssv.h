/*
 * ssv.h
 *
 *  Created on: Nov 26, 2019
 *      Author: Omar Yunus
 */

#ifndef SSV_H_
#define SSV_H_
void parse(char record[],int *acct,float *amnt);


#endif /* SSV_H_ */
