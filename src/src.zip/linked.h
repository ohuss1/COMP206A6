/*
 * linked.h
 *
 *  Created on: Nov 26, 2019
 *      Author: Omar Yunus
 */

#ifndef LINKED_H_
#define LINKED_H_
void findUpdate(int account, float amount);


#endif /* LINKED_H_ */
